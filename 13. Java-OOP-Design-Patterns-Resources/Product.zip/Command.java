public interface Command {
    String executeAction();
}
