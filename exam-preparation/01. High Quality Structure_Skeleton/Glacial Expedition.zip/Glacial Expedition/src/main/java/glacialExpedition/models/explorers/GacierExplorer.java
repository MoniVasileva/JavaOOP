package glacialExpedition.models.explorers;

public class GacierExplorer extends BaseExplorer{

    private static final double ENERGY = 40;

    public GacierExplorer(String name) {
        super(name, ENERGY);
    }
}
