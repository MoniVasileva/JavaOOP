package WorkingWithAbsraction.Exercise.TraficLights;

public enum Color {
    RED,
    GREEN,
    YELLOW;
}
